"""
Generate the system-architecture diagram for the conference paper.

Run:
    venv/Scripts/python.exe paper/figures/architecture.py
Output:
    paper/figures/architecture.png
"""

from pathlib import Path
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.patches import FancyArrowPatch

OUT = Path(__file__).parent / "architecture.png"

fig, ax = plt.subplots(figsize=(11, 6.5), dpi=200)
ax.set_xlim(0, 11)
ax.set_ylim(0, 7)
ax.set_aspect("equal")
ax.axis("off")

# Color palette
C_INPUT  = "#E8F4F8"
C_MODEL  = "#FFE5B4"
C_FUSION = "#D4EDDA"
C_OUTPUT = "#F8D7DA"
C_IOT    = "#E2D9F3"
EDGE = "#222"

def box(x, y, w, h, label, color, fontsize=10, bold=False):
    rect = patches.FancyBboxPatch(
        (x, y), w, h,
        boxstyle="round,pad=0.05,rounding_size=0.08",
        linewidth=1.4, edgecolor=EDGE, facecolor=color)
    ax.add_patch(rect)
    weight = "bold" if bold else "normal"
    ax.text(x + w/2, y + h/2, label,
            ha="center", va="center",
            fontsize=fontsize, fontweight=weight, color="#111")

def arrow(x1, y1, x2, y2, label="", offset=(0, 0)):
    ar = FancyArrowPatch((x1, y1), (x2, y2),
                         arrowstyle="-|>", mutation_scale=14,
                         linewidth=1.3, color=EDGE)
    ax.add_patch(ar)
    if label:
        mx = (x1 + x2) / 2 + offset[0]
        my = (y1 + y2) / 2 + offset[1]
        ax.text(mx, my, label, fontsize=8.5,
                ha="center", va="center", color="#333",
                bbox=dict(boxstyle="round,pad=0.18", facecolor="white",
                          edgecolor="none", alpha=0.85))

# ============================================================
# Title
# ============================================================
ax.text(5.5, 6.7, "Multimodal Crop Disease Prediction — System Architecture",
        ha="center", fontsize=12.5, fontweight="bold", color="#1A4D2E")

# ============================================================
# Inputs
# ============================================================
box(0.2, 4.5, 1.6, 0.9, "Leaf Image\n(224x224x3)", C_INPUT, 9.5)
box(0.2, 1.5, 1.6, 0.9, "ESP32 IoT Unit\n(DHT22 + Soil)", C_IOT, 9.5)

# ============================================================
# Models
# ============================================================
box(2.3, 4.5, 2.0, 0.9, "EfficientNetB0\n(ImageNet pretrained)", C_MODEL, 9.5)
box(2.3, 1.5, 2.0, 0.9, "Random Forest\n(300 trees)", C_MODEL, 9.5)

# ============================================================
# Probability vectors
# ============================================================
box(4.8, 4.5, 1.6, 0.9, "p_img\n38-D softmax", C_INPUT, 9)
box(4.8, 1.5, 1.6, 0.9, "p_sen\n38-D softmax", C_INPUT, 9)

# ============================================================
# Fusion
# ============================================================
box(7.0, 3.0, 1.8, 1.4, "Fusion MLP\n[128 -> 64 -> 38]\nLate fusion", C_FUSION, 9.5, bold=True)

# ============================================================
# Output stages
# ============================================================
box(9.3, 5.4, 1.5, 0.7, "Disease\n(top-1 class)", C_OUTPUT, 9)
box(9.3, 4.2, 1.5, 0.7, "Confidence\n(softmax prob)", C_OUTPUT, 9)
box(9.3, 3.0, 1.5, 0.7, "Severity\n(Grad-CAM)", C_OUTPUT, 9)
box(9.3, 1.8, 1.5, 0.7, "LLM advice\n(Claude API)", C_OUTPUT, 9)
box(9.3, 0.6, 1.5, 0.7, "Telegram\nalert", C_OUTPUT, 9)

# ============================================================
# Arrows
# ============================================================
# Image path
arrow(1.8, 4.95, 2.3, 4.95)
arrow(4.3, 4.95, 4.8, 4.95)
arrow(6.4, 4.85, 7.0, 4.0)

# Sensor path
arrow(1.8, 1.95, 2.3, 1.95)
arrow(4.3, 1.95, 4.8, 1.95)
arrow(6.4, 2.05, 7.0, 3.4)

# Fusion outputs
arrow(8.8, 3.9, 9.3, 5.7)
arrow(8.8, 3.8, 9.3, 4.55)
arrow(8.8, 3.7, 9.3, 3.35)
arrow(8.8, 3.5, 9.3, 2.15)
arrow(8.8, 3.3, 9.3, 0.95)

# ============================================================
# Concatenation indicator
# ============================================================
ax.text(6.7, 3.7, "concat", fontsize=8, color="#555", style="italic")

# ============================================================
# Legend
# ============================================================
legend_y = 0.0
patches_legend = [
    (C_INPUT,  "Input / Vector"),
    (C_MODEL,  "Trained Model"),
    (C_FUSION, "Fusion"),
    (C_IOT,    "IoT Hardware"),
    (C_OUTPUT, "Output"),
]
for i, (col, lab) in enumerate(patches_legend):
    rect = patches.FancyBboxPatch(
        (0.3 + i*1.7, legend_y), 0.35, 0.22,
        boxstyle="round,pad=0.0,rounding_size=0.04",
        linewidth=0.8, edgecolor=EDGE, facecolor=col)
    ax.add_patch(rect)
    ax.text(0.7 + i*1.7, legend_y + 0.11, lab, fontsize=8,
            va="center", color="#333")

plt.tight_layout()
fig.savefig(OUT, dpi=200, bbox_inches="tight", facecolor="white")
print(f"[arch] Saved: {OUT}")
plt.close(fig)
